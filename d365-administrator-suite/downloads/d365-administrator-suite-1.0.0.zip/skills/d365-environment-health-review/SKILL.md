---
name: d365-environment-health-review
description: "Use for a D365 administrator's environment health, capacity or incident review. Interpret approved admin analytics and health notices without confusing correlation with cause."
---

# Review environment health and capacity

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Exact environment/product and observation window
- Permitted admin analytics, service notices and capacity summaries with source dates
- Recent deployments/configuration changes and affected workloads

## Workflow

1. Separate current service incident evidence from an isolated app/client problem. A service notice must match the environment, region and time before it supports a hypothesis.
2. Keep database, file and log capacity units and periods distinct. High utilization is not by itself proof of the measured latency's cause.
3. Compare only equivalent environments/workloads and periods. Preserve analytics latency and gaps rather than describing delayed charts as live telemetry.
4. Build a recent-change timeline with known deployments and observation times; coincidence is not a confirmed regression.
5. Propose owner actions or escalation evidence. Do not delete logs/data, buy capacity, reset/copy environments or change retention as a generic performance fix.

## Return

An environment health brief: sourced trends, incident/change timeline, unknowns and next observation or support escalation.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Ambiguous target, incompatible measures, inaccessible analytics, proposed deletion/purchase/reset, or a service-health conclusion unsupported by the relevant time/region.

## Official references

- [Monitor and optimize your Dynamics 365 environments](https://learn.microsoft.com/dynamics365/guidance/implementation-guide/service-solution-monitor-service-health)
- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
