---
name: d365-performance-intake
description: "Use when a D365 administrator reports a slow app or asks where to start. Scope the affected Dataverse environment, app, user journey and evidence before diagnosing."
---

# Scope a performance investigation

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Product/deployment, exact tenant and environment, app and scenario
- Observed symptom, UTC window/time zone, affected population, first occurrence and last known good
- Environment owner, allowed evidence, recent changes and desired outcome

## Workflow

1. Separate product and deployment first. For unsupported products, state the scope limit and propose the correct product specialist rather than applying Dataverse guidance.
2. Ask for one reproducible journey: open a form, load a view, save a record or run an integration. Distinguish first load, warm load and save duration.
3. Record impact, environment, browser/client, region, identities as permitted, timestamps and recent changes. Do not require broad administrator access just to write an intake.
4. Classify the next evidence slice as client, server/custom code, integration/throttling, platform/capacity or unknown. A classification is not a root-cause finding.
5. Offer the smallest permitted observation plan and an incident owner. Do not enable diagnostics, reproduce production transactions or run a load test.

## Return

A concise incident card: impact, reproducible scenario, known facts, missing evidence, candidate diagnostic path and next owner.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Wrong or ambiguous environment, denied evidence, active outage requiring incident response, unsupported product, or a requested action outside the approved scope.

## Official references

- [Debug a model-driven app with Live monitor](https://learn.microsoft.com/power-apps/maker/monitor-modelapps)
- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
