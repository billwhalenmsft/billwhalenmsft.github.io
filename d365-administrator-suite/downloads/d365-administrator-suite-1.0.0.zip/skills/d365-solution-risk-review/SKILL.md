---
name: d365-solution-risk-review
description: "Use to interpret an approved solution checker report or review customization-related performance risks. Treat static findings as review inputs, not verified runtime defects."
---

# Review solution and customization risks

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Exact solution/publisher/version and report date
- Permitted solution checker findings with rule/component references
- Related runtime symptoms and ownership where available

## Workflow

1. Confirm which solution and version were analyzed, the checker scope and whether the result matches the affected environment. Do not export a solution just to obtain data.
2. Group supplied findings by rule, component, severity and owner. Preserve unsupported or unexamined components rather than implying total coverage.
3. Separate static risk from a reproduced runtime performance problem; a clean report is not a performance certificate or guaranteed import success.
4. Prioritize findings that have both a relevant user scenario and supporting evidence. State explicitly when no runtime correlation exists.
5. Draft a developer-owned sandbox remediation and recheck plan. Do not import/publish solutions, edit code, run deployments or disable security/business logic.

## Return

A finding-to-symptom matrix with sources, confidence, owner, proposed test and unresolved coverage.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Mismatched version, export or deployment request without exact approval, or a claim that checker results alone establish root cause or production safety.

## Official references

- [Improve solution performance, stability and reliability](https://learn.microsoft.com/power-apps/maker/data-platform/use-powerapps-checker)
- [Debug a model-driven app with Live monitor](https://learn.microsoft.com/power-apps/maker/monitor-modelapps)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
