---
name: dataverse-integration-load-review
description: "Use when Dataverse integrations report 429s, retries or throughput problems. Separate service protection from entitlement limits and propose evidence-based backoff and workload changes."
---

# Review integration load and throttling

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Integration identity, environment and approved observation window
- Request rate/concurrency, response codes, Retry-After when present and operation semantics
- Payload/query shape, retry policy and baseline if supplied

## Workflow

1. Separate a measured 429/service-protection response from slow requests, authentication errors, entitlement limits or a transient service incident. Do not assume every slowdown is throttling.
2. Honor a supplied Retry-After when proposing the supported client's retry behavior. If absent, consult the current SDK/provider behavior; do not invent an infinite retry or a universal numeric limit.
3. Distinguish idempotent reads from writes with uncertain outcomes. Reconcile the operation before proposing a write retry; bulk envelopes do not guarantee idempotency.
4. Review unnecessary polling, request fan-out, concurrency, selected columns and repeated queries against supplied evidence. Batching is not a way to evade limits.
5. Propose a bounded sandbox comparison with explicit load budget, cancellation and stop conditions; no production load generation or automatic tenant/integration changes.

## Return

A load/error/retry evidence table, prioritized hypotheses and a guarded test plan. No guarantee of throughput or license entitlement.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Unknown request semantics, unbounded production load, bypass requests, secret-bearing headers, or retries that might duplicate a business write.

## Official references

- [Service protection API limits](https://learn.microsoft.com/power-apps/developer/data-platform/api-limits)
- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
