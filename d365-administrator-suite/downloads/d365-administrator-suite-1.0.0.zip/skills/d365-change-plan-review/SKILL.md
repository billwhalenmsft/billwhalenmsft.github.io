---
name: d365-change-plan-review
description: "Use after an evidence-based D365 investigation to prepare a reversible change proposal, baseline and validation plan. This skill plans changes; it does not apply them."
---

# Plan and verify a controlled improvement

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Evidence-supported hypothesis and exact environment/component
- Before-state/version, proposed change and accountable owner
- Baseline, representative test population, success measure and rollback prerequisites

## Workflow

1. Require a specific hypothesis linked to sources. If absent, return to the smallest diagnostic step rather than proposing a confident fix.
2. Record exact before/after state, dependencies, affected roles, blast radius, sandbox-first test, validation window and approval owner. Authentication and destructive actions remain separate.
3. Define success and stop conditions before the test. Do not invent a target, baseline, benchmark, expected ROI or guaranteed percentage improvement.
4. Provide a concrete rollback description and verify its prerequisites with the administrator. A backup, solution version or log reference is not automatically a tested rollback.
5. After a human performs an approved change, compare equivalent before/after observations. Preserve regressions, changed sample conditions, inconclusive results and customer-impact checks. Never mark resolved from a completed deployment alone.

## Return

A review-only change card and before/after verification checklist with rollback, owner and explicit pending approvals.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

No known before-state, rollback gap, unsupported production change, approval bypass, missing baseline or a request to execute rather than plan.

## Official references

- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)
- [Improve solution performance, stability and reliability](https://learn.microsoft.com/power-apps/maker/data-platform/use-powerapps-checker)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
