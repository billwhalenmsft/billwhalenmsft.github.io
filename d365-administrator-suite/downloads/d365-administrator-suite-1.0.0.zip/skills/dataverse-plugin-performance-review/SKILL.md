---
name: dataverse-plugin-performance-review
description: "Use for slow saves, custom plug-in errors or suspected server-side extensions in Dataverse. Correlate permitted trace metadata without assuming root cause."
---

# Review plug-in and server-side evidence

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Operation, UTC window, environment and correlation/request identifiers if available
- Permitted plug-in metadata, duration fields and error summaries
- Step registration mode, solution version and relevant recent changes if known

## Workflow

1. Correlate message, table, execution mode, timing and request/correlation context where supplied. Separate synchronous user-path work from asynchronous processing.
2. Distinguish measured plug-in time, nested operations and total request time. Do not infer missing traces mean no plug-in ran or rank absent data as zero.
3. Warn that trace content can contain secrets or business data. MessageBlock and configuration fields may be restricted; a null field does not prove there was no trace. Do not request secret-bearing fields or recommend gaining System Administrator merely to bypass the restriction.
4. If evidence is insufficient, propose a separately approved bounded trace setting/time window and restoration plan. Prefer minimal scope; never leave All tracing on indefinitely.
5. Account for truncation and retention: trace text is limited and default cleanup can remove old entries. Do not change cleanup jobs or claim the retained record is a complete execution history.

## Return

A correlation table with known durations, exclusions and uncertainties, plus a developer handoff or bounded capture proposal.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Secrets/unredacted configuration, inaccessible trace fields, uncertain production target, or a request to disable plug-ins, alter registrations or enable trace settings directly.

## Official references

- [Tracing and logging](https://learn.microsoft.com/power-apps/developer/data-platform/logging-tracing)
- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
