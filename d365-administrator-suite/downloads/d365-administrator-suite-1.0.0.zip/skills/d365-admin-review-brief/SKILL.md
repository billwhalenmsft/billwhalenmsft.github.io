---
name: d365-admin-review-brief
description: "Use to summarize a scoped D365 performance investigation for IT administrators and technical leaders. Produce sourced visual-ready findings, unknowns and decisions without overstating fixes."
---

# Turn diagnostics into an administrator review

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Reviewed incident scope and minimized findings with citations
- Supplied measures with units, periods, sample population and method
- Open hypotheses, proposed changes, owners and observed verification state

## Workflow

1. Lead with employee impact and the decision required, then show what was observed versus suspected, changed versus merely proposed, and verified versus unknown.
2. Choose a scenario timeline, component table or comparison appropriate to the supplied data. For missing data show an evidence checklist, not a fabricated chart.
3. For p50/p95, require raw eligible samples and a declared method or an explicitly supplied statistic with sample context; do not average percentiles. Mark synthetic examples and incomparable populations.
4. If a verified host Charts and Dashboards capability is available and authorized for the data, supply sanitized structured measures with units/dates/citations. Never assume its schema or send diagnostic logs to an external chart service.
5. Keep a readable table/text equivalent, visible unknowns and an owner/next-step panel. No generated visualization or narrative may auto-run scripts, fix settings or approve a change.

## Return

A short administrator brief with sourced table/optional supported chart, hypothesis confidence, next decision and the actual no-change/changed/verified state.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Missing metric provenance, incompatible periods, unapproved external renderer, people-ranking request or an unsupported claim of customer resolution.

## Official references

- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
