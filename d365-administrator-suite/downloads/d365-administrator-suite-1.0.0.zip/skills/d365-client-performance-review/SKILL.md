---
name: d365-client-performance-review
description: "Use for model-driven app form, page, view or browser slowness. Review authorized Live monitor evidence and distinguish custom script time, network requests and load context."
---

# Explain a slow form or page

## Read first

Read [the shared evidence/action contract](./references/shared-contract.md) before proceeding. It governs all steps, including graphical outputs and stop conditions.

## Scope

Dynamics 365 Sales, Customer Service and Field Service on Dataverse/model-driven apps. Finance and Operations, Business Central, on-premises and infrastructure tuning require separately qualified guidance.

## Required context

- Scoped scenario and UTC window
- Minimized authorized Live monitor events, request timings and available browser/client details
- App/solution version and load type; comparable baseline if supplied

## Workflow

1. Confirm whether the evidence represents cold or warm navigation, the same form/view and comparable client conditions. Do not add overlapping timings as if they were independent.
2. Use supplied FullLoad, customScriptTime, request and error attribution when present. Identify publisher/solution/component only when the trace actually supplies them.
3. Treat synchronous XMLHttpRequest, repeated requests, large responses and expensive custom scripts as hypotheses unless the captured scenario supports attribution.
4. Explain why a slow end-to-end experience is not automatically a database, network or Microsoft service problem. List competing hypotheses and the observation that would distinguish them.
5. Plan a time-limited Live monitor session only if needed. Joining shares session data with the monitor owner: confirm recipient, scope and permission; the administrator starts it separately.

## Return

A sourced timing breakdown or table, suspected contributor with confidence, contradictory evidence and a minimal next test.

Follow the shared response contract: sourced facts, explicit hypotheses/unknowns, visual-ready table or supported chart plus readable fallback, next owner and actual activity receipt. This is an instruction package, not a diagnostic engine; no change is executed.

## Stop or hand off

Missing scenario/time attribution, unapproved capture sharing, sensitive request contents, or a request to change scripts/disable controls without a reviewed change.

## Official references

- [Debug a model-driven app with Live monitor](https://learn.microsoft.com/power-apps/maker/monitor-modelapps)
- [Measure and maintain Power Platform solution performance](https://learn.microsoft.com/power-platform/architecture/key-concepts/performance/tools)

Reviewed 2026-10-20; recheck current feature availability and documentation in the actual host.
